// src/components/layouts/Layout.jsx - Main Layout with Store Integration
import React from 'react';
import { Outlet } from 'react-router-dom';
import Header from './Header';
import Footer from './Footer';
import MobileBottomNav from './MobileBottomNav';

const Layout = () => {
  return (
    <div className="min-h-screen flex flex-col bg-[var(--bg-black)]">
      {/* Background Effects */}
      <div className="fixed inset-0 overflow-hidden pointer-events-none">
        <div className="absolute top-0 left-1/4 w-96 h-96 bg-[var(--color-orange)] opacity-5 blur-[100px] rounded-full"></div>
        <div className="absolute bottom-0 right-1/4 w-96 h-96 bg-[var(--color-text-4)] opacity-5 blur-[100px] rounded-full"></div>
        <div className="absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 w-96 h-96 bg-[var(--color-text-5)] opacity-5 blur-[100px] rounded-full"></div>
      </div>

      {/* Main Content */}
      <div className="relative z-10 flex flex-col min-h-screen">
        <Header />
        
        {/* Main content area - full width for pages to control their own containers */}
        <main className="flex-1">
          <Outlet />
        </main>
        
        {/* Footer - Always visible on all devices */}
        <Footer />
        
        {/* Mobile Bottom Navigation - Only visible on mobile */}
        <MobileBottomNav />
      </div>
    </div>
  );
};

export default Layout;