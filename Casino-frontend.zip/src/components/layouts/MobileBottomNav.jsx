// src/components/layouts/MobileBottomNav.jsx
import React from "react";
import { Link } from "react-router-dom";

const MobileBottomNav = () => {
  const menuItems = [
    { id: "honeypot", name: "HoneyPot", icon: "🍯", path: "/game/honeypot" },
    { id: "coinflip", name: "CoinFlip", icon: "🪙", path: "/game/coinflip" },
    { id: "pumpdump", name: "Pump.Dump", icon: "📈", path: "/game/pumpdump" },
    { id: "futures", name: "Futures", icon: "📊", path: "/game/futures" },
    { id: "chat", name: "Chat", icon: "💬", path: "/chat" },
  ];

  return (
    <div className="lg:hidden fixed bottom-0 left-0 right-0 z-50 bg-black/95 backdrop-blur-xl border-t border-white/10">
      <div className="relative">
        {/* Gradient line at top */}
        <div className="absolute top-0 left-0 right-0 h-[1px] bg-gradient-to-r from-transparent via-[#F07730] to-transparent"></div>

        {/* Navigation Container */}
        <div className="flex items-center justify-around px-2 py-2">
          {menuItems.map((item) => (
            <Link
              key={item.id}
              to={item.path}
              className="group flex flex-col items-center justify-center py-2 px-3 rounded-xl transition-all hover:bg-white/10 active:scale-95"
            >
              {/* Icon Container */}
              <div className="relative mb-1">
                {/* Glow effect for active item */}
                <div className="absolute inset-0 bg-[#F07730] blur-lg opacity-0 group-hover:opacity-50 transition-opacity"></div>

                {/* Icon */}
                <span className="relative text-2xl group-hover:scale-110 transition-transform">
                  {item.icon}
                </span>
              </div>

              {/* Label */}
              <span className="text-[10px] text-gray-400 group-hover:text-[#F07730] transition-colors font-medium">
                {item.name}
              </span>
            </Link>
          ))}
        </div>

        {/* Active Indicator (shows for first item by default) */}
        <div className="absolute bottom-0 left-[10%] w-[16%] h-1 bg-gradient-to-r from-[#F07730] to-[#EFD28E] rounded-t-full transform -translate-x-1/2 transition-all duration-300"></div>
      </div>
    </div>
  );
};

export default MobileBottomNav;
